#!/usr/bin/env bash

# img2fpm.sh formally pbm2fpm.sh
#
# Create an MLVFS formatted focus pixel map file
# or optionally a dcraw "badpixels" formatted file
# from an image file.
#
#
# The output file can be used with MLVFS
# (or dcraw) to remove the focus pixels from MLV
# files shot on Canon 100D, 650D, 700D, EOSM and EOSM2 cameras.
#
# Requires bash, sed, file 
# and (optional) ImageMagick for png, jpg, tiff, etc.
#
# The script will create a P1 version Portable Bit Map (PBM) file
# that may be deleted by the user after it finishes processing.
#
# 2018-2019 Daniel A. Fort
# This is free and unencumbered software released into the public domain.

usage()
{
cat << EOF
Usage: img2fpm.sh [-dv] <input_file>
Parameters:
    -d  dcraw "badpixels" format
    -q  quiet mode

example:
    ./imgfpm.sh 80000346_1872x1060.pbm

    Displays which coordinates are being processed as it creates a
    focus pixel map file named 80000346_1872x1060.fpm
    WARNING: Script cannot handle filenames with spaces.

Defaults to .fpm (focus pixel map) files.
For use with cameras that show their focus pixels in raw video.

80000301 / EOS Rebel T4i / 650D / Kiss X6i
80000326 / EOS Rebel T5i / 700D / Kiss X7i
80000331 / EOS M
80000346 / EOS Rebel SL1 / 100D / Kiss X7
80000355 / EOS M2

EOF
}

VERBOSE=
DCRAW=
input_file=
output_file=
ext=
pbm_format=
pbm_data=
i=
x=
y=

while getopts “hqd” OPTION; do
    case $OPTION in
    h)  usage
        exit 0
        ;;
    q)  QUIET=1
        ;;
    d)  DCRAW=1
        ;;
    ?)  usage
        exit 1
        ;;
    esac
done

shift $((OPTIND - 1))

input_file="$1"

if [ -z "$input_file" ]; then usage; exit 1; fi

# This script can only work with plain text PBM files.
# If the input file is a different format, run it through Imagemagick.
# ************* to do - it should be able to work with P4 PBM files
ext="${input_file##*.}"

if [ $ext != "pbm" ]; then # Send it to ImageMagick and hope for the best
    if !(command -v magick >/dev/null); then
        usage
        echo "ImageMagick not found."
        echo "Only plain text (P1) PBM files can be processed."
        exit 1
    else magick convert "$input_file" -colorspace gray -compress none -depth 8 "${input_file%.*}.pbm"
        input_file="${input_file%.*}.pbm"
        ext="pbm"
    fi
fi

if [ $ext == "pbm" ]; then
    pbm_format=$(head -n 1 $input_file)

    if [ $pbm_format != "P1" ]; then
        if !(command -v mogrify >/dev/null); then
            usage
            echo "ImageMagick not found."
            echo "Only plain text (P1) PBM files can be processed."
            exit 1
        else mogrify -colorspace gray -compress none -depth 8 "$input_file"
        fi
    fi
fi


# Use an appropriate file extension
if [ $DCRAW ]; then output_file="${input_file%.*}.txt"
else output_file="${input_file%.*}.fpm"
fi

if [ ! $QUIET ]; then
    echo input_file  = "$input_file"
    echo output_file = "$output_file"
fi

# set the indexs
i=1
x=0
y=0

# Strip out the header and start a text stream.
sed -e 's/[[:space:]]*#.*// ; s/[[:space:]]*P1.*// ; /^[[:space:]]*$/d' "$input_file" | tr -s " " "\n" |

while read pbm_data; do

    # First piece is the width
    if [ $i -eq 1 ]; then
        width=$pbm_data
        if [ ! $QUIET ]; then echo width  = "$width"; fi
    fi

    # Next piece is the height
    if [ $i -eq 2 ]; then
        height=$pbm_data
        if [ ! $QUIET ]; then
            echo height = "$height"
            echo "Finding mapped pixel x,y coordinates:"
        fi
    fi

    # Items 3 through width x height +3 is the raster
    # We need to know the end of the raster because:
    # "You can put any junk you want after the raster, if it starts with a white space character."
    if [ $i -gt 2 ]; then
        if [ $x -lt $width ]; then
            if [[ $pbm_data == 1 ]]; then
                if [ $DCRAW ]; then echo -e "$x \t $y \t 0" >> "$output_file"
                else echo -e "$x \t $y" >> "$output_file"
                fi
                if [ ! $QUIET ]; then printf "\r%04s %04s\r" "$x" "$y"; fi
            fi
            ((x++))
            if [ $x -eq $width ]; then
                ((x=0)); ((y++))
            fi
        fi
    fi

    ((i++))

done

# If ImageMagick is installed convert the portable bit map file to portable network graphic
# format to save space.
if (command -v magick >/dev/null); then
    if [ ! $QUIET ]; then echo "Converting pbm file to png to save space."; fi
	magick convert "${input_file%.*}.pbm" "${input_file%.*}.png"
	rm "${input_file%.*}.pbm"
fi

exit 0
