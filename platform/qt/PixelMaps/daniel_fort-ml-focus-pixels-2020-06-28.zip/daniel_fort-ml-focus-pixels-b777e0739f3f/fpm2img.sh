#!/usr/bin/env bash

# fpm2img.sh
#
# Create an image file from a dcraw ".badpixels"
# or an MLP "dead_pixel_list.txt" or a .fpm "focus pixel map file
#
# Reads the file, ignoring any blank lines or comments or lines
# that start with -P (MLP dcraw command), extracts the xy coordinates,
# discards the "UNIX time of death for one pixel" field (required by dcraw)
# and creates a Portable Bit Map graphic file showing the location of the
# mapped focus pixels. This .pbm file can be opened with Photoshop, Gimp, etc.
# it can also be opened with a text editor.
#
# The file name must have the image size preceded with an underscore and
# followed by the filename extension. A filename extension of .fpm identifies
# the file as a focus pixel map file.
#
# 2016 - 2019 Daniel A. Fort
# This is free and unencumbered software released into the public domain.

usage()
{
cat << EOF
Usage: fpm2img.sh [-qs] <input_file>
Parameters:
    -q  quiet mode
    -s	single image file - default is to make a seperate image file
                            for multiple pass map files

example:
    ./fpm2img.sh 80000346_1872x1060.fpm

    Displays which coordinates are being processed as it creates a
    Portable Bitmap file named 80000346_1872x1060.pbm in P1 (ascii)
    format that can be used to visualize the focus pixels a focus 
    pixel map (.fpm) file.

Works with dcraw "badpixels" files and .fpm (focus pixel map) files.
For use with cameras that show their focus pixels in raw video.

80000301 / EOS Rebel T4i / 650D / Kiss X6i
80000326 / EOS Rebel T5i / 700D / Kiss X7i
80000331 / EOS M
80000346 / EOS Rebel SL1 / 100D / Kiss X7
80000355 / EOS M2

To save on storage space it is recommended to convert the pbm output
to a binary image file format like png, jpeg or even type P4 pbm. 

If ImageMagick is install it will automatically convert to a
grayscale bitmap style Portable Network Graphics format file.

EOF
}

SINGLE=
QUIET=
SEDCMD=

while getopts “hsq” OPTION; do
    case $OPTION in
    h)  usage
        exit 0
        ;;
    s)	SINGLE=1
    	;;
    q)  QUIET=1
        ;;
    ?)  usage
        exit 1
        ;;
    esac
done

shift $((OPTIND - 1))

input_file="$1"

if [[ -z "$input_file" ]]; then
    usage
    exit 1
fi

# These are used several times so let's make them functions

initialize_file(){
	# Print file header
	echo "P1" > $output_file
	echo $width $height >> $output_file
	echo "# Plain PBM generated from $input_file by fpm2img.sh" >> $output_file
	echo "# source code available in the ML Focus Pixels project" >> $output_file
	echo "# https://bitbucket.org/daniel_fort/ml-focus-pixels" >> $output_file
}

pass_number(){

    if [ $SINGLE ]; then
    	output_file="${input_file%.*}.pbm"
    else
    	output_file="${input_file%.*}_$f.pbm"
    fi
    
    if [ ! $QUIET ]; then echo "output_file     = $output_file"; fi
}

line_lenth_check(){
    if [[ $(($i % $columns)) == 0 ]]; then echo >> $output_file; fi
}

fill_remaining(){
    if [ ! $QUIET ]; then echo "Filling in remaining pixels"; fi
    
    while [[ $i -le $((width * height)) ]]; do

        if [ ! $QUIET ]; then printf "\r%08s" "$(($((width * height)) - $i))"; fi

        echo -n "0 " >> $output_file
        line_lenth_check
        ((i++))
    done
}

# Initialize variables
ext="${input_file##*.}"
size=`echo $input_file | sed -n 's/.*_\(.*\)\..*/\1/p'`
width=$(echo $size | cut -d 'x' -f 1)
height=$(echo $size | cut -d 'x' -f 2)
i=1 # index
f=1 # multi-pass map file counter
columns=35 # columns limit in the pbm file
new_map_check=0 # see if a new multi-pass image file is needed
pass_number

if [ ! $QUIET ]; then
    echo "input_file      = $input_file"
    echo "input file type = $ext"
    echo "width           = $width"
    echo "height          = $height"
    echo "Mapping focus pixel x,y coordinates:"
fi

if [ "$ext" == "fpm" ]; then
    fields="x y"
else
    fields="x y t"
fi

initialize_file

# Strip out header from focus pixel map file or dcraw "badpixels" format file
# and start a sed text stream
#
# When using the SINGLE option sort the entire fpm file and remove duplicates
if [ $SINGLE ]; then
	SEDCMD="sed -e 's/[[:space:]]*#.*// ; s/[[:space:]]*-P.*// ; /^[[:space:]]*$/d' $input_file | sort -k 2 -k 1 -n | uniq -u"
else
	SEDCMD="sed -e 's/[[:space:]]*#.*// ; s/[[:space:]]*-P.*// ; /^[[:space:]]*$/d' $input_file"
fi

eval $SEDCMD |

(	# Start a sub-shell to keep variable values. Works but it slows down the script.
	while read $fields; do
   
		if [[ $y -lt $new_map_check ]] && [ ! $SINGLE ]; then
			if [ ! $QUIET ]; then echo; fi
        	fill_remaining
			if [ ! $QUIET ]; then echo; fi
        	((f++))
        	pass_number
        	initialize_file
        	new_map_check=0
        	i=1 # reset index
        fi

        fp_pos=$(($((x + 1)) + $((y * width))))

        while [[ $i -ne $fp_pos ]]; do
            echo -n "0 " >> $output_file
            line_lenth_check
            ((i++))
            if [ ! $QUIET ]; then printf "\r%04s %04s\r" "$x" "$y"; fi
        done


        if [[ $i -eq $fp_pos ]]; then
            echo -n "1 " >> $output_file
            line_lenth_check
            ((i++))
        fi
        
        new_map_check=$y

    done

	fill_remaining

	# Make sure pbm file ends with a linefeed
	echo >> $output_file

	# Also do a linefeed on the console
	if [ ! $QUIET ]; then echo; fi

	# If it isn't a multi-pass map file and we didn't ask
	# for a single pass map file, take out the pass number
	if [ ! $SINGLE ] && [[ $f -eq 1 ]]; then
		if [ ! $QUIET ]; then echo "renaming $output_file to  ${input_file%.*}.pbm"; fi
		mv $output_file "${input_file%.*}.pbm"
	fi

	# If ImageMagick is installed - convert pbm to png
	if (command -v magick >/dev/null); then
		if [ ! $QUIET ]; then echo "Converting from PBM to PNG image file format"; fi
		if [[ $f -eq 1 ]]; then
			magick convert "${input_file%.*}.pbm" "${input_file%.*}.png"
			rm ${input_file%.*}.pbm
		else
			for i in $(seq 1 $f); do 
				magick convert "${input_file%.*}_$i.pbm" "${input_file%.*}_$i.png"
				rm ${input_file%.*}_$i.pbm
			done
		fi
	fi

) # end sub-shell

exit 0
