# README #

This is a simple bash shell script to create focus pixel map files from Magic Lantern raw video using the following cameras:

* Canon EOS 100D / Rebel SL1 / Kiss X7
* Canon EOS 650D / Rebel T4i / Kiss X6i
* Canon EOS 700D / Rebel T5i / Kiss X7i
* Canon EOS M
* Canon EOS M2

### What is this repository for? ###

* Dealing with Focus Pixels in raw video

* [Discussion on Magic Lantern forum](http://www.magiclantern.fm/forum/index.php?topic=16054)

### To Do ###

* Support digital dolly