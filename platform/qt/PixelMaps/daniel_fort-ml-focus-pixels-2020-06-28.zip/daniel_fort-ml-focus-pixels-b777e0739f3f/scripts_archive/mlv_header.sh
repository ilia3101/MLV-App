# Some more command line tricks this time
# for reading MLV headers.

# Most of the information seems to be in
# a fixed offset location and is rather
# easy to find.

# Note that little-endian words need to
# be read right to left.

printf "resolution width: "
h=`xxd -s 0x44 -l 2 -p "$1"`
printf "%d\n" 0x"${h:2:2}${h:0:2}"

printf "resolution height: "
h=`xxd -s 0x46 -l 2 -p "$1"`
printf "%d\n" 0x"${h:2:2}${h:0:2}"

printf "raw buffer height: "
h=`xxd -s 0x50 -l 2 -p "$1"`
printf "%d\n" 0x"${h:2:2}${h:0:2}"

printf "raw buffer width: "
h=`xxd -s 0x54 -l 2 -p "$1"`
printf "%d\n" 0x"${h:2:2}${h:0:2}"

printf "camera information: "
h=`xxd -s 0x01dc -l 6 -p "$1"`
printf "%s\n" 0x"${h:6:2}${h:4:2}${h:2:2}${h:0:2}"

# However, the crop and pan is recorded for each
# frame so we need to find the 'magic' that
# identifies that block. We're not going to attempt
# to support dynamic panning for now so let's just
# grab the first frame.

# Find the first "VIDF" block, "56 49 44 46" in hex
# the 1!N; append the next line when not on the last
# line in case "VDIF" is split by a newline. Keep
# a large enough chunk to include where the panX
# and panY information is located.

k=`xxd -p "$1" | sed -n '1!N; /56494446/{p;n;p;q;}' | tr -d '\n' |  grep -Eo -m 1 '56494446.{48}'`

# Next find the panX and cropX and print them
# to the terminal:

printf "panX: "
printf "%d\n" 0x"${k:50:2}${k:48:2}"
printf "panY: "
printf "%d\n" 0x"${k:54:2}${k:52:2}"
