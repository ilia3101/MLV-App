#!/usr/bin/env bash

# batch_mlv2badpixels.sh
#
# Usage: batch_mlvbadpixels.sh [directory]
#
# A simple script that will run
# mlv2badpixels.sh on every MLV file
# in a directory. Options not supported
# and there is no error checking.
#
# 2016 Daniel A. Fort
# This is free and unencumbered software released into the public domain.

mlv_files=$1"/*.MLV"
for i in $mlv_files
    do
    ./mlv2badpixels.sh $i
done
