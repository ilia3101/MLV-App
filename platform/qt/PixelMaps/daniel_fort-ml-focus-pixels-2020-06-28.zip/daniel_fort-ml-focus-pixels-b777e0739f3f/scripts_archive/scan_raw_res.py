import os, sys
from struct import unpack

# hardcoded, from raw_lv_get_resolution
column_factor = 4

# try some autodetection
cam = sys.argv[1].split("/")[0]
column_factors = {
    "5D3" : 8,
    "70D" : 8,
    "50D" : 2,
    "5D2" : 2,
    "60D" : 2,
    "7D"  : 2,
    "7DM" : 2,
    "500D" : 1,
    "550D" : 2,
    "600D" : 2,
    "1000D" : 1,
    "1100D" : 2,
    "1200D" : 2,
    "1300D" : 2,
}

if cam in column_factors:
    column_factor = column_factors[cam]

def getLongLE(d, a):
   return unpack('<L',(d)[a:a+4])[0]

def guess_vidmode(addr):
    r0,v0 = getLongLE(data, addr-16), getLongLE(data, addr-12)
    r1,v1 = getLongLE(data, addr-8), getLongLE(data, addr-4)
    r2,v2 = getLongLE(data, addr), getLongLE(data, addr+4)
    r3,v3 = getLongLE(data, addr+8), getLongLE(data, addr+12)

    if r0 == 0xC0F0600C and v0 == 0 and \
       r1 == 0xC0F06010 and v1 == 0 and \
       r2 in [0xC0F06800, 0xC0F06084] and v2 == 0 and \
       r3 in [0xC0F06804, 0xC0F06088] and v3 == 0 and \
       1:
        #~ print "valid pattern 1"
        pass
    else:
        return

    for a in range(addr, addr+0x1000, 4):
        v = [getLongLE(data, ax) for ax in range(a, a+6*4, 4)]
        #~ print [hex(x) for x in v]
        # match this pattern:
        # 0x1B701B7     # 0xC0F06008 - FPS timer A, lo == hi
        # 0x1B701B7     # 0xC0F0600C - idem
        # 0x1B7         # 0xC0F06010 - idem, only lo
        # 0x10017       # 0xC0F06800 - first scan line / column group
        # 0x528011B     # 0xC0F06804 - last scan line / column group
        # 0x1B7 ?       # 0xC0F06824 - optional, may be the same as timer A, slightly different on other models
        if v[0] == v[1]                 and \
           v[0] >> 16 == v[0] & 0xFFFF  and \
           v[0] & 0xFFFF == v[2]        and \
           v[2] > 0                     and \
           v[3] & 0xFF00FF00 == 0       and \
           v[4] & 0x0000FF00 != 0       and \
           v[4] & 0xFF000000 != 0       and \
           1:
            xres = (v[4] & 0xFFFF) - (v[3] & 0xFFFF)
            yres = (v[4] >> 16) - (v[3] >> 16)
            print "%X: %d x %-4d (timer A = %d)" % (r2, xres * column_factor, yres, v[2] + 1)


def guess_vidmode_2(addr):
    r0,v0 = getLongLE(data, addr-16), getLongLE(data, addr-12)
    r1,v1 = getLongLE(data, addr-8), getLongLE(data, addr-4)
    r2,v2 = getLongLE(data, addr), getLongLE(data, addr+4)
    r3,v3 = getLongLE(data, addr+8), getLongLE(data, addr+12)

    if r0 == 0xC0F06010 and v0 == 0 and \
       r1 == 0xC0F06014 and v1 == 0 and \
       r2 in [0xC0F06800, 0xC0F06084] and v2 == 0 and \
       r3 in [0xC0F06804, 0xC0F06088] and v3 == 0 and \
       1:
        #~ print "valid pattern 2"
        pass
    else:
        return

    for a in range(addr, addr+0x1000, 4):
        v = [getLongLE(data, ax) for ax in range(a, a+7*4, 4)]
        #~ print [hex(x) for x in v]
        # match this pattern:
        # 0x2210221     # 0xC0F06008 - FPS timer A, lo == hi
        # 0x2210221     # 0xC0F0600C - idem
        # 0x221         # 0xC0F06010 - idem, only lo
        # 0x669         # 0xC0F06014 - FPS timer B
        # 0x1000C       # 0xC0F06800 - first scan line / column group
        # 0x4E501EC     # 0xC0F06804 - last scan line / column group
        # 0x21F         # 0xC0F06824 - close to timer A (?!)
        if v[0] == v[1]                 and \
           v[0] >> 16 == v[0] & 0xFFFF  and \
           v[0] & 0xFFFF == v[2]        and \
           v[2] > 0                     and \
           v[3] & 0xFFFF0000 == 0       and \
           v[3] > 0                     and \
           v[4] & 0xFF00FF00 == 0       and \
           v[5] & 0x0000FF00 != 0       and \
           v[5] & 0xFF000000 != 0       and \
           v[6] & 0xFFFF0000 == 0       and \
           1:
            xres = (v[5] & 0xFFFF) - (v[4] & 0xFFFF)
            yres = (v[5] >> 16) - (v[4] >> 16)
            print "%d x %-4d (timer A = %d, B = %d)" % (xres * column_factor, yres, v[2] + 1, v[3] + 1)

data = open(sys.argv[1]).read()

lo = -1

for addr in xrange(0, len(data)-4, 4):
    this = getLongLE(data, addr)

    if this == 0xC0F06088 or this == 0xC0F06804:
        next = getLongLE(data, addr+4)
        if next != 0 and next & 0xF0000000 != 0xC0000000:
            #~ print "%X: 0x%X" % (this, next)
            hi = next
            if lo & 0xFF00FF00 == 0 and hi & 0x80008000 == 0 and \
               lo & 0xFF > 0 and (lo >> 16) & 0xFF > 0 and \
               lo & 0xFFFF > 0 and (lo >> 16) & 0xFFFF > 0:
                    xres = (hi & 0xFFFF) - (lo & 0xFFFF)
                    yres = (hi >> 16) - (lo >> 16)
                    print "%X: %d x %d" % (this, xres * column_factor, yres)

    if this == 0xC0F06084 or this == 0xC0F06800:
        next = getLongLE(data, addr+4)
        if next != 0 and next & 0xF0000000 != 0xC0000000:
            #~ print "%X: 0x%X" % (this, next)
            lo = next
        
        if next == 0:
            #~ print "guess at %x" % addr
            guess_vidmode(addr)
            guess_vidmode_2(addr)

    if this == 0xC0F08180:
        next = getLongLE(data, addr+4)
        if next == 0:
            xn = getLongLE(data, addr-8)
            xa = getLongLE(data, addr-24)
            xb = getLongLE(data, addr-20)
            z1 = getLongLE(data, addr-16)
            z2 = getLongLE(data, addr-12)
            z3 = getLongLE(data, addr-4)
            if z1 == z2 == z3 == 0:
                if xa == xb:
                    print "EDMAC: %d x %d" % (xa*8/14, xn+1)
                    #~ print [hex(getLongLE(data, addr+x)) for x in range(-32,8,4)]
