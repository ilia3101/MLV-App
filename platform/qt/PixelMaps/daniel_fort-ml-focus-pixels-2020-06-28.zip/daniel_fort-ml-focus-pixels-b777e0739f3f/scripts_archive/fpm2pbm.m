function M = fpm2pbm(image_size, filename)
    # fpm2pbm.m
    #
    # Create a Portable Bit Map file from an
    # MLVFS .fpm (focus pixel map file)
    #
    # Based on fpm2pbm.sh, http://www.magiclantern.fm/forum/index.php?topic=16054.msg161309#msg161309
    # Requires GNU octave.
    #
    # Usage fpm2pbm(image_size, filename)
    # example:
    # octave> fpm2pbm([1108 2592], '80000331_2592x1108.fpm');
    # shell$ octave-cli --eval "fpm2pbm([1108 2592], '80000331_2592x1108.fpm');"
    #
    # This is free and unencumbered software released into the public domain.
    
    M = ones(image_size);
    d = dlmread(filename);
    x = d(:,1); y = d(:,2);
    i = sub2ind(image_size, y+1, x+1);
    M(i) = 0;
    imwrite(M, [filename '.pbm']);
end
