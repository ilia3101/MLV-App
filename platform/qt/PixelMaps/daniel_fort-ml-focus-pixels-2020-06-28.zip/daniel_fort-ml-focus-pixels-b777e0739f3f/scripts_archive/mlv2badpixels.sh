#!/usr/bin/env bash

# mlv2badpixels.sh
#
# http://www.magiclantern.fm/forum/index.php?topic=16054
#
# Create a dcraw ".badpixels" formatted file from
# an MLV file (Magic Lantern raw video)
# For removing focus pixels from Magic Lantern raw video
# files shot on on Canon 100D, 650D, 700D, EOSM and EOSM2 cameras.
#
# The focus pixel map files (.fpm) for the raw video buffer
# need to be in the same working path as this script.
#
# This script does not support filenames and paths with spaces
# and there is very little error checking.
#
# 2016 - 2019 Daniel A. Fort
# This is free and unencumbered software released into the public domain.


usage()
{
cat << EOF
Usage: mlv2badpixels.sh [-hmq][-o output_file] <input_file>
Parameters:
    -h           Show this message
    -o filename  Customize Filename
    -q           Quiet mode

example:
    ./mlv2badpixels.sh -v -o M21-1747_1_2015-12-06_0001_C0000.txt M21-1747.MLV

    creates a file named M21-1747_1_2015-12-06_0001_C0000.txt that can be
    used to remove the focus pixels on the dng files extracted from M21-1747.MLV

This script will create a dcraw "badpixels" file
to remove focus pixels from an MLV file shot with
cameras that show their focus pixels in raw video.

EOS Rebel T4i / 650D / Kiss X6i
EOS Rebel T5i / 700D / Kiss X7i
EOS Rebel SL1 / 100D / Kiss X7
EOS M
EOS M2

EOF
}

VERBOSE=
output=

workingDir=`dirname "$0"`
cd "${workingDir}"

while getopts “hmo:q” OPTION; do
  case $OPTION in
  h)usage
    exit 0
    ;;
  o)output="$OPTARG"
    ;;
  q)QUIET=1
    ;;
  :)echo "Error: -$OPTARG requires an argument"
    usage
    exit 1
    ;;
  ?)usage
    exit 1
    ;;
  esac
done

shift $((OPTIND - 1))

if [ ! $QUIET ]; then echo workingDir = $workingDir; fi

MLV="$1"

if [[ -z $MLV ]]; then
  usage
  exit 1
fi

if [ ! $QUIET ]; then echo input file = $MLV; fi

camera_model=`mlv_dump -v "$MLV" | grep Camera"[[:space:]]"Model | head -1 | sed -e 's/^[ Camera \s Model: \s 0x]*//'`

resolution=`mlv_dump -v "$MLV" | grep Res | head -1 | sed -e 's/^[ Res:]*//'`
pan=`mlv_dump -v "$MLV" | grep Pan | head -1 | sed -e 's/^[ Pan:]*//'`

IFS='x'
  read -r width height <<< "$resolution"
  read -r panPosX panPosY <<< "$pan"
unset IFS

cropX=$((panPosX + 7 & ~7))
cropY=$((panPosY & ~1))

if [ ! $QUIET ]; then echo Resolution = $resolution; echo Pan = $pan; echo Crop = $cropX"x"$cropY; fi

raw_width=`mlv_dump -v "$MLV" | grep width | head -1 | sed -e 's/^[ width]*//'`
raw_height=`mlv_dump -v "$MLV" | grep height | head -1 | sed -e 's/^[ height]*//'`
raw_buffer=$raw_width"x"$raw_height

#Heuretic code. If close to match fpm file straighten things right
if [[ "$raw_buffer" = \1808x11* ]]; then
raw_buffer=1808x1190
elif
[[ "$raw_buffer" = \1808x72* ]]; then
raw_buffer=1808x727
elif
[[ "$raw_buffer" = \1872x10* ]]; then
raw_buffer=1872x1060
elif
[[ "$raw_buffer" = \2592x110* ]]; then
raw_buffer=2592x1108
fi

fpm=$camera_model"_"$raw_buffer".fpm"

if [ ! $QUIET ]; then echo Camera Model = $camera_model; fi

case $camera_model in
  80000301)
    camera=650D
    ;;
  80000326)
    camera=700D
    ;;
  80000331)
    camera=EOSM
    ;;
  80000346)
    camera=100D
    ;;
  80000355)
    camera=EOSM2
    ;;
  *) exit 2
    ;;
esac

if [ ! $QUIET ]; then
  echo Camera = $camera
  echo Raw Buffer = $raw_buffer
  echo Map File = $fpm
fi

case $raw_buffer in
  1736x21**)
  	video_mode=anamorphic
    ;;
  1808x72*)
    video_mode=mv720
    ;;
  1808x75*)
    video_mode=mv1080
    ;;
  1808x10**)
    video_mode=mv1080
    ;;
  1808x11**)
    video_mode=mv1080
    ;;
  1808x19**)
  	video_mode=anamorphic
    ;;
  1808x20**)
  	video_mode=anamorphic
    ;;
  1872x10**)
    video_mode=mv1080crop
    ;;
  2592x110*)
    video_mode=zoom
    ;;
  2592x14**)
    video_mode=2.5k
    ;;
  3072x13**)
    video_mode=3k
    ;;
  3104x14**)
    video_mode=3k
    ;;
  4072x17**)
    video_mode=4k
    ;;
  4104x25**)
    video_mode=4k
    ;;
  5280x3***)
    video_mode=full_resolution
    ;;
  *) exit 3
    ;;
esac

if [ ! $QUIET ]; then echo Video Mode = $video_mode; fi

if [ -z "$output" ]; then
    output=$camera"_"$video_mode"_"$resolution".txt"
fi

if [ ! $QUIET ]; then echo Output File = "$output"; fi

if test -f "$output"; then
  rm "$output"
  if [ ! $QUIET ]; then echo Removing previous file = "$output"; fi
fi

while read -r raw_buffer_x raw_buffer_y; do
  ((x = $raw_buffer_x - $cropX))
  ((y = $raw_buffer_y - $cropY))
  if (( "$x" >= 0 )) && (( "$y" >= 0 )); then
    if (( "$x" <= "$width" )) && (( "$y" <= "$height" )); then
      echo -e "$x \t $y \t 0" >> "$output"
    fi
  fi
done < "$fpm"
