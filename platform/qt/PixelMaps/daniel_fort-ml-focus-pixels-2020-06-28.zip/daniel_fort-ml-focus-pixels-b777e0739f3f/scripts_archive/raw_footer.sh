# RAW file footer structure in char
#
# /* file footer data */
# typedef struct
# {
#     unsigned char magic[4];
#     unsigned short xRes;
#     unsigned short yRes;
#     unsigned int frameSize;
#     unsigned int frameCount;
#     unsigned int frameSkip;
#     unsigned int sourceFpsx1000;
#     unsigned int reserved3;
#     unsigned int reserved4;
#     struct raw_info raw_info;
# } lv_rec_file_footer_t;

# The RAW file footer is 192 bytes long so we need to
# back up 192 bytes (hexadecimal c0) from the end of the file.
# The -s is the seek offset and the hex number is negative
# because we're seeking from the end of the file.
# The -g 1 option groups the output in single bytes
# (2 hex characters)

printf "\nRAW footer:\n"
xxd -s -0xc0 -g 1 "$1"

# Note the 4-byte 'magic' RAWM at the start of the footer.
# We're interested in the frame size of the raw file
# and the two bytes following RAWM, 188 bytes (hex bc)
# from the end is the image width size in pixels.
# We want just those two bytes so we'll suppress everything
# else (-p) so grouping no longer can be applied.

printf "\nMagic:\n"
printf "0x"
xxd -s -0xc0 -l 4 -p "$1"
xxd -s -0xc0 -l 4 -c 1 "$1"

printf "\nWidth in hexidecimal:\n"
printf "0x"
xxd -s -0xbc -l 2 -p "$1"

# Print this out as a decimal number doesn't work because
# it is "little endian" and the bytes need to be read in
# reverse order. Note the "0x" to tell printf that this is
# a hex number.

printf "\nNormal hexadecimal to decimal conversion doesn't work on little endian encoding:\n"
printf "%d\n" 0x`xxd -s -0xbc -l 2 -p "$1"`

# The solution is to put the hex number in a variable and
# print it out in reverse order.

printf "\nConverted from little endian encoding:\n"
w=`xxd -s -0xbc -l 2 -p "$1"`
printf "0x${w:2:2}${w:0:2} \n"

# Finally print out the image width from the raw footer.

printf "\nImage width taken from the raw footer\n"
printf "from original hex through conversion to decimal:\n"
printf "0x$w\n"
printf "0x"
printf "${w:2:2}${w:0:2} \n"
printf "%d\n" 0x"${w:2:2}${w:0:2}"

# Take the next two bytes and do the same thing for the image height.

printf "\nImage height taken from the raw footer:\n"
h=`xxd -s -0xba -l 2 -p "$1"`
echo 0x$h
printf "%d\n" 0x"${h:2:2}${h:0:2}"


# 'magic' (192,4) 52 41 57 4d | width (188,2) 00 05 | height (186,2) d0 02 | frameSize (184,4) 00 a0 18 00 |
# Frame count (180,2) 28 00 | Frame skip (178,6) 00 00 01 00 00 00 | FPS (172,2) ac 5d | etc.

printf "\nFrame size:\n"
s=`xxd -s -0xb8 -l 4 -p "$1"`
echo 0x$s
printf "%d\n" 0x"${s:4:2}${s:2:2}${s:0:2}"

printf "\nFrame count:\n"
x=`xxd -s -0xb4 -l 2 -p "$1"`
echo 0x$x
printf "%d\n" 0x"${x:2:2}${x:0:2}"

printf "\nFrame skip:\n"
k=`xxd -s -0xb2 -l 6 -p "$1"`
echo 0x$k
printf "%d\n" 0x"${k:6:2}${k:4:2}${k:2:2}${k:0:2}"

printf "\nFrames per second:\n"
fps=`xxd -s -0xac -l 2 -p "$1"`
echo 0x$fps
fps="${fps:2:2}${fps:0:2}"
fps=$((16#$fps))
fps=$(awk "BEGIN {printf \"%.3f\",${fps}/1000}")
echo $fps
